#include <glad/glad.h>
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
//#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "camera.h"
#include "shader.h"
#include "cylinder.h"
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
glm::vec3 cameraPos = glm::vec3(0.0f, 4.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

glm::vec3 lightPos(0.0f, 4.0f, 0.0f);

int main() {
	// Initiate and Configure GLFW
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "6-5 Milestone: Kyle T. Moses", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/7.3.camera.vs", "shaderfiles/4.1.texture.fs");
	Shader lightCubeShader("shaderfile/2.1.light_cube.vs", "shaderfile/2.1.light_cube.fs");
	Shader lightingShader("shaderfile/6.multiple_lights", "shaderfiles/6.multiple_lights.fs");

	unsigned int lightCubeVAO, lightCubeVBO;


	//Building verticies for base of remote
	// Position and Color data
	float verticies[] = {
	   2.0f, 0.0f, 1.0f,	0.0f, 0.0f,
	   2.0f, 0.0f, -1.0f,	1.0f, 0.0f,
	   -2.0f, 0.0f, -1.0f,	1.0f, 1.0f,
	   -2.0f, 0.0f, -1.0f,	1.0f, 1.0f,
	   -2.0f, 0.0f, 1.0f,	0.0f, 1.0f,
	   2.0f, 0.0f, 1.0f,	0.0f, 0.0f,

	   2.0f, 0.0f, 1.0f,	0.0f, 0.0f,
	   -2.0f,  0.0f, 1.0f,	1.0f, 0.0f,
	   2.0f,  0.5f, 1.0f,	1.0f, 1.0f,
	   -2.0f,  0.0f, 1.0f,	1.0f, 1.0f,
	   2.0f,  0.5f, 1.0f,	0.0f, 1.0f,
	   -2.0f, 0.5f, 1.0f,	0.0f, 0.0f,

	   2.0f, 0.0f, -1.0f,	0.0f, 0.0f,
	   -2.0f, 0.0f, -1.0f,	1.0f, 0.0f,
	   2.0f, 0.5f, -1.0f,	1.0f, 1.0f,
	   -2.0f, 0.0f, -1.0f,	1.0f, 1.0f,
	   2.0f, 0.5f, -1.0f,	0.0f, 1.0f,
	   -2.0f, 0.5f, -1.0f,	0.0f, 0.0f,

	   2.0f,  0.0f, 1.0f,	0.0f, 0.0f,
	   2.0f, 0.0f, -1.0f,	1.0f, 0.0f,
	   2.0f, 0.5f, -1.0f,	1.0f, 1.0f,
	   2.0f,  0.0f, 1.0f,	0.0f, 0.0f,
	   2.0f,  0.5f, 1.0f,	0.0f, 1.0f,
	   2.0f, 0.5f, -1.0f,	1.0f, 1.0f,

	   -2.0f,  0.0f, 1.0f,	0.0f, 0.0f,
	   -2.0f, 0.0f, -1.0f,	1.0f, 0.0f,
	   -2.0f, 0.5f, -1.0f,	1.0f, 1.0f,
	   -2.0f,  0.0f, 1.0f,	1.0f, 1.0f,
	   -2.0f, 0.5f, 1.0f,	0.0f, 1.0f,
	   -2.0f, 0.5f, -1.0f,	0.0f, 0.0f,

	   2.0f,  0.5f, 1.0f,	0.0f, 0.0f,
	   2.0f, 0.5f, -1.0f,	1.0f, 0.0f,
	   -2.0f, 0.5f, -1.0f,	1.0f, 1.0f,
	   -2.0f, 0.5f, -1.0f,	1.0f, 1.0f,
	   -2.0f, 0.5f, 1.0f,	0.0f, 1.0f,
	   2.0f,  0.5f, 1.0f,	0.0f, 0.0f,
	};

	float planeVerticies[] = {
		10.0f,  0.0f, 10.0f,	0.0f, 0.0f,
		10.0f,  0.0f, -10.0f,	1.0f, 0.0f,
		-10.0f,  0.0f, -10.0f,	1.0f, 1.0f,
		-10.0f,  0.0f, -10.0f,	1.0f, 1.0f,
		-10.0f,  0.0f, 10.0f,	0.0f, 1.0f,
		10.0f,  0.0f, 10.0f,	0.0f, 0.0f,
	};


	//Add VBOs and VAOs here (This allow for more shapes to be drawn)
	unsigned int VBO, VAO;
	unsigned int planeVBO, planeVAO;
	unsigned int middleRVBO, middleRVAO;
	unsigned int powerRVBO, powerRVAO;
	unsigned int candleBaseVBO, candleBaseVAO;
	unsigned int candleTopVBO, candleTopVAO;
	unsigned int weight1VBO, weight1VAO;
	unsigned int weight2VBO, weight2VAO;
	unsigned int weightHandleVBO, weightHandleVAO;

	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(verticies), verticies, GL_STATIC_DRAW);

	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// Texture Coord Position
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glGenVertexArrays(1, &planeVAO);
	glGenBuffers(1, &planeVBO);
	glBindVertexArray(planeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVerticies), planeVerticies, GL_STATIC_DRAW);

	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// Texture Coord Position
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glGenVertexArrays(1, &middleRVAO);
	glGenBuffers(1, &middleRVBO);
	glBindVertexArray(middleRVAO);
	glBindBuffer(GL_ARRAY_BUFFER, middleRVBO);

	glGenVertexArrays(1, &powerRVAO);
	glGenBuffers(1, &powerRVBO);
	glBindVertexArray(powerRVAO);
	glBindBuffer(GL_ARRAY_BUFFER, powerRVBO);

	glGenVertexArrays(1, &candleBaseVAO);
	glGenBuffers(1, &candleBaseVBO);
	glBindVertexArray(candleBaseVAO);
	glBindBuffer(GL_ARRAY_BUFFER, candleBaseVBO);

	glGenVertexArrays(1, &candleTopVAO);
	glGenBuffers(1, &candleTopVBO);
	glBindVertexArray(candleTopVAO);
	glBindBuffer(GL_ARRAY_BUFFER, candleTopVBO);

	glGenVertexArrays(1, &weight1VAO);
	glGenBuffers(1, &weight1VBO);
	glBindVertexArray(weight1VAO);
	glBindBuffer(GL_ARRAY_BUFFER, weight1VBO);

	glGenVertexArrays(1, &weight2VAO);
	glGenBuffers(1, &weight2VBO);
	glBindVertexArray(weight2VAO);
	glBindBuffer(GL_ARRAY_BUFFER, weight2VBO);

	glGenVertexArrays(1, &weightHandleVAO);
	glGenBuffers(1, &weightHandleVBO);
	glBindVertexArray(weightHandleVAO);
	glBindBuffer(GL_ARRAY_BUFFER, weightHandleVBO);

	//glGenVertexArrays(1, &lightCubeVAO);
	//glGenBuffers(1, &lightCubeVBO);
	//glBindVertexArray(lightCubeVAO);
	//glBindBuffer(GL_ARRAY_BUFFER, lightCubeVBO);


	// Load and Create Texture
	// Texture 1 = Remote Base texture
	// Texture 2 = Carpet/Plane texture
	// Texture 3 = Middle Remote Button texture
	// Texture 4 = Power Remote Button texture && Top Candle texture
	// Texture 5 = Candle Base texture
	// Texture 6 = Metal Weights texture
	unsigned int texture1, texture2, texture3, texture4, texture5, texture6;

	// texture 1
	glGenTextures(1, &texture1);
	glBindTexture(GL_TEXTURE_2D, texture1);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data = stbi_load("images/remoteBase.jpg", &width, &height, &nrChannels, 0);
	if (data) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// texture 2
	glGenTextures(1, &texture2);
	glBindTexture(GL_TEXTURE_2D, texture2);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width1, height1, nrChannels1;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data1 = stbi_load("images/carpet.jpg", &width1, &height1, &nrChannels1, 0);
	if (data1) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width1, height1, 0, GL_RGB, GL_UNSIGNED_BYTE, data1);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data1);

	// texture 3
	glGenTextures(1, &texture3);
	glBindTexture(GL_TEXTURE_2D, texture3);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width2, height2, nrChannels2;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data2 = stbi_load("images/Very_Black_screen.jpg", &width2, &height2, &nrChannels2, 0);
	if (data2) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width2, height2, 0, GL_RGB, GL_UNSIGNED_BYTE, data2);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data2);

	// texture 4
	glGenTextures(1, &texture4);
	glBindTexture(GL_TEXTURE_2D, texture4);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width3, height3, nrChannels3;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data3 = stbi_load("images/power.jpg", &width3, &height3, &nrChannels3, 0);
	if (data3) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width3, height3, 0, GL_RGB, GL_UNSIGNED_BYTE, data3);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data3);

	// texture 5
	glGenTextures(1, &texture5);
	glBindTexture(GL_TEXTURE_2D, texture5);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width4, height4, nrChannels4;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data4 = stbi_load("images/yellow.jpg", &width4, &height4, &nrChannels4, 0);
	if (data4) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width4, height4, 0, GL_RGB, GL_UNSIGNED_BYTE, data4);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data4);

	// texture 6
	glGenTextures(1, &texture6);
	glBindTexture(GL_TEXTURE_2D, texture6);
	//texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width5, height5, nrChannels5;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* data5 = stbi_load("images/ironTexture.jpg", &width5, &height5, &nrChannels5, 0);
	if (data5) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width5, height5, 0, GL_RGB, GL_UNSIGNED_BYTE, data5);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data5);

	// telling opengl for each sampler to which texure unit it belongs to
	ourShader.use();
	ourShader.setInt("texture1", 0);
	ourShader.setInt("texture2", 1);
	ourShader.setInt("texture3", 2);
	ourShader.setInt("texture4", 3);
	ourShader.setInt("texture5", 4);
	ourShader.setInt("texture6", 5);

	glm::mat4 model;
	float angle;

	// render loop
	// ___________
	while (!glfwWindowShouldClose(window)) {
		// per-frame time logic
		//______________
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		//__________
		processInput(window);

		// render
		//_______
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//Trying to create a spotlight.
		lightingShader.use();
		ourShader.setVec3("viewPos", camera.Position);
		ourShader.setFloat("material.shininess", 32.0f);
		ourShader.setVec3("spotLight.position", camera.Position);
		ourShader.setVec3("spotLight.direction", camera.Front);
		ourShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
		ourShader.setVec3("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
		ourShader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
		ourShader.setFloat("spotLight.constant", 1.0f);
		ourShader.setFloat("spotLight.linear", 0.09);
		ourShader.setFloat("spotLight.quadratic", 0.032);
		ourShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
		ourShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));


		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1);

		// Activiate Shaders
		ourShader.use();

		// pass projection matrix to shader (note that in this case it could change every frame)
		glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
		ourShader.setMat4("projection", projection);

		// camera/view transformation
		glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		ourShader.setMat4("view", view);

		// render boxes
		glBindVertexArray(VAO);
		// Calculate the model matrix
		model = glm::mat4(1.0f); // Initializing the matrix
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
		angle = 0.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, 36);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(planeVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
		angle = 0.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, 6);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture3);
		glBindVertexArray(middleRVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(0.0f, -0.1f, 0.0f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C1(0.5, 30, 1.25, true, true, true);
		C1.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture4);
		glBindVertexArray(powerRVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(-1.5f, -0.1f, -0.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C2(0.1, 30, 1.25, true, true, true);
		C2.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture5);
		glBindVertexArray(candleBaseVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(-5.0f, 0.75f, -3.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C3(1.5, 30, 1.5, true, true, true);
		C3.render();
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture3);
		glBindVertexArray(candleTopVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(-5.0f, 1.5f, -3.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C4(1.55, 30, 0.2, true, true, true);
		C4.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture6);
		glBindVertexArray(weight1VAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(5.0f, 1.5f, 4.5f));
		angle = 90.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C5(1.55, 30, 1.0, true, true, true);
		C5.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture6);
		glBindVertexArray(weight1VAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(5.9f, 1.5f, 0.5f));
		angle = 90.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C6(1.55, 30, 1.0, true, true, true);
		C6.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture6);
		glBindVertexArray(weightHandleVAO);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(5.3f, 1.5f, 2.5f));
		angle = 90.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);
		static_meshes_3D::Cylinder C7(0.5, 30, 4.0, true, true, true);
		C7.render();

		//// also draw the lamp object
		//lightCubeShader.use();
		//lightCubeShader.setMat4("projection", projection);
		//lightCubeShader.setMat4("view", view);
		//model = glm::mat4(1.0f);
		//model = glm::translate(model, lightPos);
		//model = glm::scale(model, glm::vec3(0.2f)); // a smaller cube
		//lightCubeShader.setMat4("model", model);

		//static_meshes_3D::Cylinder C8(0.5, 30, 4.0, true, true, true);
		//C8.render();
		//glBindVertexArray(lightCubeVAO);

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// This de-allocates all resources once they are no longer needed 
	// Not a bad idea, helps safe resources
	// But all VAOs and VBOs in there
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);

	// glfw: Terminate, Clearing all previously allocated GLFW resources.
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraSpeed = 2.5 * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
}

// glfw: Whenever the window size changed (by OS or use resize) this callback function executes
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.1f; // change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	fov -= (float)yoffset;
	if (fov < 1.0f)
		fov = 1.0f;
	if (fov > 45.0f)
		fov = 45.0f;
}